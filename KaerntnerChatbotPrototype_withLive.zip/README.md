# Kärntner Dialekt Chatbot – Prototype

## Ordner
- `index.html`, `css/`, `js/`, `data/` – Frontend ohne Backend (läuft lokal im Browser).
- `server/` – Minimaler Proxy-Server, um **Live-Modus** mit einer LLM-API zu nutzen.

## Demo vs. Live
- **Demo** (Standard): Regelbasierter Bot + Dialekt-Postprocessing. Kein API-Key nötig.
- **Live**: Antworten kommen von einem LLM über deinen lokalen Proxy. Dialekt-Postprocessing bleibt im Frontend.

### Live-Modus aktivieren
1. Node installieren (>=18).
2. In den `server/` Ordner wechseln und Abhängigkeiten installieren:
   ```bash
   cd server
   npm install
   ```
3. Umgebungsvariable setzen und Server starten:
   ```bash
   # PowerShell (Windows)
   setx OPENAI_API_KEY "DEIN_API_KEY"
   # danach neues Terminal öffnen
   node server.js
   ```
   Der Server läuft standardmäßig auf `http://localhost:8787`.

4. Im Frontend `js/config.js` die Zeile anpassen:
   ```js
   mode: 'live'
   ```

5. `index.html` im Browser öffnen. Der Chat nutzt jetzt den Proxy.

## Sicherheit
- **Kein** API-Key im Frontend. Keys gehören ausschließlich in die Server-Umgebung.
- Der Proxy limitiert die Felder auf das Nötigste (`message`, `model`, `system`). Erweitere bei Bedarf.

## Evaluationshinweis (für das Meeting)
- Zeig Translator/Chat + Korpus-Tab (Editierbarkeit).
- Erkläre den Live-Flow (Frontend → Proxy → LLM, Postprocessing Dialekt).
- Skizziere Evaluationsplan: WER/CER für STT, MOS/UMOS für TTS, UX-Fragebogen (Verständlichkeit, Authentizität, Latenz).
